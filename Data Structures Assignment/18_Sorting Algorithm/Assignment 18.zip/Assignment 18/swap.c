#include "main.h"



void swap(int *p, int *q)
{
	//Swapping Logic Implementation
    int temp;
    temp = *p;
    *p = *q;
    *q = temp;
    
}
