#include "main.h"


void print(int a[], int n)
{
	int i;
	for(i = 1; i <=n; i++)
	{
		printf("%d ", a[i]);
	}
	printf("\n");
}
